<?php
	$conecta=mysqli_connect("localhost","root","","projetosmv");

	session_start();

	echo "Matrícula excluída!<p>";
	echo "<p><a href='index2.php'>Voltar ao menu </a>";
?>
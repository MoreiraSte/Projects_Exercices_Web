<?php
$conexao = mysqli_connect ("localhost", "root", "", "projetosmv");
	if (!$conexao) {
		echo "Erro na conexão com a base de dados!";
	}
	else {		
		$nome_curso = $_POST["nome_curso"];
		$horario = $_POST["horario"];
		session_start();
		$email = $_SESSION['emaillogado'];
		
		$query = mysqli_query ($conexao, "INSERT INTO matricula (nome_curso, horario,email) VALUES ('$nome_curso' , '$horario','$email')");
		echo '<script language="JavaScript" charset="utf-8">
		alert ("Matricula Cadastrada!") </script><p>';
		echo '<a href="index2.php"> Retornar a página principal </a>';
	}
?>
<?php
   $email=$_GET["email"];
   $senha=$_GET["senha"];
   
	$conecta=mysqli_connect("localhost","root","","projetosmv");
	
	$verificarls=mysqli_query($conecta,"select * from usuario where email='$email' and senha='$senha'");
	$campostabela = mysqli_fetch_assoc($verificarls);
 
	if(mysqli_num_rows($verificarls)==0)
	{
		echo "Usuario invalido!";
		echo "<p><a href='login2.html'>Tente novamente ou cadastre um novo usuario</a>";
	}
	else 
	{	
		/*	if ($campostabela["vezes"]>3)
			{
				echo "Usuario desativado!";
				echo "<p><a href='login2.html'>Tente outro ou cadastre um novo usuário</a>";
			}	
		else
			{*/
				session_start();
				$_SESSION['emaillogado'] = $email;
				$_SESSION['nomelogado'] = $campostabela['nome'];
				$_SESSION['fotologado'] = $campostabela['foto'];
				
				include "index2.php"; 
	}
?>
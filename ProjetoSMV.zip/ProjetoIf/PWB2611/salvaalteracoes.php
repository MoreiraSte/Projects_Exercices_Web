 <?php

	$conecta=mysqli_connect("localhost","root","","projetosmv");

	session_start();

	$emaillogado=$_SESSION['emaillogado'];

	$alteranome=$_GET['alteranome'];

	$alteraemail=$_GET['alteraemail'];

	$alterasenha=$_GET['alterasenha'];

	$verificaemaillogado=mysqli_query($conecta,"update usuario set nome='$alteranome',senha='$alterasenha',email='$alteraemail' where email='$emaillogado'");
	echo "Dados atualizados!<p>";
	echo "<p><a href='index2.php'>Voltar ao menu </a>";


?>
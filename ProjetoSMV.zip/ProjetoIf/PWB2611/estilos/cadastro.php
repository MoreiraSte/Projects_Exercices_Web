<?php
	$nome = $_GET["nome"];
	$email = $_GET["email"];
	$senha = $_GET["senha"];
	$curso = $_GET["curso"];
	$erro = 0;

	echo "<p> Em construção...</p>";
?>
	
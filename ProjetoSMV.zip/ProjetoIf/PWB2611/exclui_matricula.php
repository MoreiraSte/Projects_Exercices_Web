<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<?php
	$conecta=mysqli_connect("localhost","root","","projetosmv") or die("Erro ao conectar ao banco de dados requisitado");
	
	if (!isset($_SESSION))
		session_start();

	$email = $_SESSION['emaillogado'];
	$nomeusuariologado=$_SESSION['nomelogado'];
	
	$buscardadosnoBD=mysqli_query($conecta,"select * from matricula where email='$email'");
	
	echo "$nomeusuariologado, esses são os cursos que você se matriculou: <p>";
	echo "<table border=1>";
	echo "<th>Curso</th><th>Horario</th><tr>";
		
	while ($exibe = mysqli_fetch_array($buscardadosnoBD)) 
	{
    	echo"<td>".$exibe['nome_curso']."</td>";
		echo"<td>".$exibe['horario']."</td><tr>";
    }
	echo "</table>";

	$verificausuariologado = mysqli_query($conecta, "select * from matricula where email='$email'");

	$guardacampo=mysqli_fetch_assoc($verificausuariologado);
	
	$sql = "DELETE FROM matricula WHERE email='$email'"; 
	mysqli_query($conecta,$sql) or die("Erro ao tentar excluir");
	mysqli_close($conecta);

	echo "<a href='salvar_exclusao.php'><input type='submit' value='Confirmar exclusão'></a>";
	
	echo "<p><a href='index2.php'>Voltar ao menu </a>";

?>
<?php
//Maria Eduarda Alves, Stephany Moreira e Vinicius Souza
// *** Parâmetros de configuração da operação ***

// Limitar as extensões? (sim ou nao)
$limitar_ext = "sim";

// extensões autorizadas
$extensoes_validas = array(".pdf");

//caminho absoluto onde os arquivos serão armazenados
$caminho_absoluto = "C:/xampp/htdocs/ProjetoIf/PWB2611/experiencias";

// Limitar o tamanho do arquivo? (sim ou nao)
$limitar_tamanho = "nao";

// tamanho limite do arquivo em bytes
$tamanho_bytes = "2000000";

// se já existir o arquivo, indica se ele deve ser sobrescrito (sim ou nao)
$sobrescrever = "nao";

?>

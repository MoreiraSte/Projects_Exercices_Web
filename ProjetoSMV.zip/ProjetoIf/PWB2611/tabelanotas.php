<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<?php
	$conexao = mysqli_connect ("localhost", "root", "", "projetosmv");	
	
	if (!isset($_SESSION))
		session_start();
	
	$email = $_SESSION['emaillogado'];
	$nomeusuariologado=$_SESSION['nomelogado'];
	
	$buscardadosnoBD=mysqli_query($conexao,"select * from visita"); 
	
	echo "Essas foram as notas que avaliaram nosso web site: ";
	echo "<table border=1>";
	echo "<th>Nota</th><th>Comentario</th><tr>";
		
	while ($exibe = mysqli_fetch_array($buscardadosnoBD)) 
	{
    	echo"<td>".$exibe['nota']."</td>";
		echo"<td>".$exibe['comentario']."</td><tr>";
		
    }
	
	echo "</table>";
	echo "<p><a href='index2.php'>Voltar ao menu</a>";
?>
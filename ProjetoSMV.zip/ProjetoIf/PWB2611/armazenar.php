<?php
//Maria Eduarda Alves, Stephany Moreira e Vinicius Souza
	$conexao = mysqli_connect ("localhost", "root", "", "projetosmv");
	if (!$conexao) {
		echo "Erro na conexão com a base de dados!";
	}
	else {
		$varnome = $_POST["nome"];
		$varfone = $_POST["telefone"];
		$vardatanasc = $_POST["datanasc"];
		$varemail = $_POST["email"];
		$varcidade = $_POST["cidade"];
		$query = mysqli_query ($conexao, "INSERT INTO contato
		(nomecompleto, datanasc, telefone, email, cidade) VALUES
		('$varnome', '$vardatanasc', '$varfone', '$varemail', '$varcidade')");
		echo '<script language="JavaScript" charset="utf-8">
		alert ("Contato Cadastrado!") </script><p>';
		echo "Muito obrigada por deixar o suas informacoes de contato, iremos te passar as informacoes!!";
		echo '<a href="index.html"> Retornar ao formulário</a>';
	}
?>
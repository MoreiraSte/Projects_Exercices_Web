
<html>
	<head>
		<title>Instituto Federal</title>
		<meta charset ="utf-8">
		<link rel="stylesheet" type="text/css" href="estilos/css.css">
	</head>
	
	<body>
			<a href="#topo"><img class="voltar" src="imagens/seta.png" alt=""></a>

	
		<div id="logo" >
			<img  class="logo" src="imagens/logo.png" alt="log">o
		</div>
		
		<div id="topo">
			<img  class="slogan" src="imagens/slogan.gif" alt="logo">

		</div>

		<div id="conteudo">
		<center>
		<h3 style="color:white">BOAS VINDAS AO USUÁRIO</h3><hr>
		</center>
		<center>
		<?php
		$conexao = mysqli_connect ("localhost", "root", "", "projetosmv");	
		
		if (!isset($_SESSION))
			session_start();

		$email = $_SESSION['emaillogado'];
		$nomeusuariologado=$_SESSION['nomelogado'];
		
		echo "<span style='color:white;'>$nomeusuariologado, seja bem vindo(a)<br><br></span>";
		
		$fotologado=$_SESSION['fotologado'];
		echo "<img src=imagens/$fotologado width='200' height='200'>";
	?>
	</center>
			<p style="color:white"> Opções: </p>
			<ul class="menu2">
			<li class="i_menu2"><a href="matricula.html">Matricula</a></li>
			<li class="i_menu2"><a href="tabela_cursos_usuario.php">Tabela cursos</a></li>
			<li class="i_menu2"><a href="alteracadastro.php">Alterar cadastro</a></li>
			<li class="i_menu2"><a href="visita.html">Caderno de Visitas</a></li>
			<li class="i_menu2"><a href="exclui_matricula.php">Excluir Matrícula</a></li>
			<li class="i_menu2"><a href="tabelanotas.php">Tabela Notas</a></li>
			<li class="i_menu2"><a href="index.html">Logout</a></li>
			<li class="i_menu2"><a href="criadores.html">Criadores</a></li>
			</ul>
<br><br><br><br>
<br><br><br><br><br><br><br><br>
	
</body>
</html>
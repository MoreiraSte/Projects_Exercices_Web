
<?php
$conexao = mysqli_connect ("localhost", "root", "", "projetosmv");
	if (!$conexao) {
		echo "Erro na conexão com a base de dados!";
	}
	else {		
		$nota = $_POST["nota"];
		$comentario = $_POST["comentario"];
		session_start();
		$email = $_SESSION['emaillogado'];
		
		$query = mysqli_query ($conexao, "INSERT INTO visita (nota, comentario, email) VALUES ('$nota' , '$comentario', '$email')");
		echo '<script language="JavaScript" charset="utf-8">
		alert (" Obrigado por comentar e dar sua nota para nossa escola!") </script><p>';
		echo '<a href="visita.html"> Retornar ao formulario </a>';
	}
?>
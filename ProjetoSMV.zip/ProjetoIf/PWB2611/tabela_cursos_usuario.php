<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<?php
	$conexao = mysqli_connect ("localhost", "root", "", "projetosmv");	
	
	if (!isset($_SESSION))
		session_start();

	$email = $_SESSION['emaillogado'];
	$nomeusuariologado=$_SESSION['nomelogado'];
	
	$buscardadosnoBD=mysqli_query($conexao,"select * from matricula where email='$email'"); //select * matricula order by horario
	
	echo "$nomeusuariologado, você fez as seguintes matrículas: <p>";
	echo "<table border=1>";
	echo "<th>Curso</th><th>Horario</th><tr>";
		
	while ($exibe = mysqli_fetch_array($buscardadosnoBD)) 
	{
    	echo"<td>".$exibe['nome_curso']."</td>";
		echo"<td>".$exibe['horario']."</td><tr>";
		
    }
	
	echo "</table>";
	echo "<p><a href='index2.php'>Voltar ao menu</a>";
?>





<?php
	 $senha = $_GET["senha"];
	 $criptografando = base64_encode($senha);
	 echo "Poderia mandar para o banco de dados a senha criptografada: $criptografando<br>";
	 echo "Descriptografado: ";
	 echo base64_decode($criptografando);

	$conexao = mysqli_connect ("localhost", "root", "", "projetosmv");
	if (!$conexao)
	{
		echo "Erro na conexão com a base de dados!";
	}
	else {
		$varemail = $_GET["email"];
		$varsenha = $_GET["senha"];
		$varnome = $_GET["nome"];
		$varfoto = $_GET["foto"];
		
		$query = mysqli_query ($conexao, "INSERT INTO usuario (email, senha, nome, foto) VALUES
		('$varemail', '$varsenha', '$varnome', '$varfoto')");
		echo '<script language="JavaScript" charset="utf-8">
		alert ("Contato Cadastrado!") </script><p>';
		echo '<a href="index.html"> Retornar ao login</a>';
	}
?>

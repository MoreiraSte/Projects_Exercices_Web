<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<?php
	$conecta=mysqli_connect("localhost","root","","projetosmv");

	session_start();

	$emaillogado=$_SESSION['emaillogado'];

	$verificausuariologado = mysqli_query($conecta, "select * from usuario where email='$emaillogado'");

	$guardacampo=mysqli_fetch_assoc($verificausuariologado);

	echo "<form name='alteradados' method='get' action='salvaalteracoes.php'>";

	echo "Nome: <input type='text' name='alteranome' value=".$guardacampo['nome']."><p>";

	echo "Email: <input type='text' name='alteraemail' value=".$guardacampo['email']."><p>";

	echo "Senha: <input type='text' name='alterasenha' value=".$guardacampo['senha']."><p>";

	echo "<input type='submit' value='Confirmar alteracao'>";
	
	echo '<a href="index2.php"> Retornar ao login</a>';
?>
